let name = 'Tshiamo';

function hello(name)
{
    console.log("Hello "+ name);
}

hello(name);

//Another Way

function Hello(name)
{
    return ('Hello ' + name);
}

console.log(Hello(name));