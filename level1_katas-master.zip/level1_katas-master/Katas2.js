let integer = 18;

function evenOrOdd(integer) {
    if ((integer % 2) === 1){
        console.log("Odd");
    }else{
        console.log("Even");
    }
}

evenOrOdd(integer);